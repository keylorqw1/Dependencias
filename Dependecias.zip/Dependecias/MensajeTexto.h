#ifndef MENSAJETEXTO_H
#define MENSAJETEXTO_H
#include "Avisador.h"

class MensajeTexto : public Avisador {
public:
	void enviar(string mensaje);
};

#endif
