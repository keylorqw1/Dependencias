#include "Correo.h"

void Correo::enviar(string mensaje) {
	cout << "Correo: " << mensaje << endl;
}
