#include <iostream>
#include "Correo.h"
#include "MensajeTexto.h"
#include "Pedido.h"
using namespace std;

int main() {
	Correo correo;
	MensajeTexto texto;
	Pedido pedido;
	
	pedido.confirmar(correo);
	pedido.confirmar(texto);
	
	return 0;
}
