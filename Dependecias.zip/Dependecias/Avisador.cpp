#include "Avisador.h"

Avisador::~Avisador() {}
