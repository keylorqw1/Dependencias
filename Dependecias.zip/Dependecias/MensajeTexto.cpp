#include "MensajeTexto.h"

void MensajeTexto::enviar(string mensaje) {
	cout << "Mensaje de texto: " << mensaje << endl;
}
