#ifndef PEDIDO_H
#define PEDIDO_H
#include "Avisador.h"

// Pedido no es nada dependiente de mensaje de texto,y tampoco de correo
class Pedido {
public:
	void confirmar(Avisador &avisador);
};

#endif
