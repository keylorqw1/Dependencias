#ifndef CORREO_H
#define CORREO_H
#include "Avisador.h"

class Correo : public Avisador {
public:
	void enviar(string mensaje);
};

#endif
