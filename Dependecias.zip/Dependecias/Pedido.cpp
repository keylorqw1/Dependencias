#include "Pedido.h"

void Pedido::confirmar(Avisador &avisador) {
	avisador.enviar("Tu pedido fue confirmado");
}
