


#ifndef AVISADOR_H
#define AVISADOR_H
#include <iostream>
using namespace std;

// Idea general: "algo que avisa". No dice como
class Avisador {
public:
	virtual ~Avisador();
	virtual void enviar(string mensaje) = 0;
};

#endif
